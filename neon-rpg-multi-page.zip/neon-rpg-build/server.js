import express from "express";
import OpenAI from "openai";
import dotenv from "dotenv";
import path from "path";
import { fileURLToPath } from "url";

dotenv.config();
const app = express();
const __dirname = path.dirname(fileURLToPath(import.meta.url));
app.use(express.json({ limit: "2mb" }));
app.use(express.static(path.join(__dirname, "public")));

const client = process.env.OPENAI_API_KEY
  ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY })
  : null;

app.get("/api/health", (_req, res) => {
  res.json({ configured: Boolean(client) });
});

app.post("/api/chat", async (req, res) => {
  try {
    if (!client) return res.status(503).json({
      error: "OPENAI_API_KEY is not configured in the .env file."
    });

    const { character, messages } = req.body || {};
    if (!character?.name || !Array.isArray(messages) || messages.length === 0) {
      return res.status(400).json({ error: "Character information or messages are missing." });
    }

    const safe = (v, max = 1500) => String(v || "").slice(0, max);
    const profile = [
      `نام: ${safe(character.name, 80)}`,
      `سن: ${safe(character.age, 40)}`,
      `جنسیت: ${safe(character.gender, 40)}`,
      `Nationality: ${safe(character.nation, 80)}`,
      `Role / occupation: ${safe(character.role || character.job, 120)}`,
      `Appearance: ${safe(character.look || [character.hair, character.eyes].filter(Boolean).join(", "), 300)}`,
      `Backstory: ${safe(character.story || character.backstory, 1000)}`,
      `Personality: ${safe(character.personality, 500)}`,
      `Relationship: ${safe(character.relationship, 200)}`,
      `Mood: ${safe(character.mood, 100)}`
    ].join("\n");

    const transcript = messages.slice(-30).map(m => ({
      role: m.role === "assistant" ? "assistant" : "user",
      content: safe(m.text || m.content, 4000)
    }));

    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-5.6",
      instructions: `You are roleplaying as the character described below. Stay in character, maintain a consistent personality, backstory, motivations, and relationship dynamics. Remember prior conversation details and avoid contradictions. Keep the conversation natural, vivid, and interactive. Never decide the user’s actions or feelings for them. Reply in the language used by the latest user message. Usually answer in 1–3 paragraphs.\n\nCharacter profile:\n${profile}`,
      input: transcript
    });

    res.json({ reply: response.output_text || "..." });
  } catch (error) {
    console.error("Chat error:", error);
    res.status(500).json({ error: "AI response failed. Check the model and API connection." });
  }
});

const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`NEON RPG running at http://localhost:${port}`));
