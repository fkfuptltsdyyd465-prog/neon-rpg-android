# NEON RPG — Single Screen Edition

A mobile-first, English-language roleplay chat app with one central chat screen and quick-access overlays.

## Included
- Rose character portrait and immersive neon city wallpaper
- Single-screen chat workspace with desktop side rail and mobile bottom navigation
- Character creator (age, gender, hair, eyes, personality, relationship, backstory)
- Upload character portraits and a custom phone wallpaper
- Character switching, profile, relationship meter and mood panel
- Multiple worlds / locations
- Quests, demo coin rewards, cosmetic store and fashion hub
- Diary / memory journal and character phone panel
- Theme color controls, local backup export/import
- Local browser storage and PWA install support
- Optional server-side OpenAI Responses API integration

## Run locally
1. Install Node.js 20+.
2. In this folder run `npm install`.
3. Copy `.env.example` to `.env` and set `OPENAI_API_KEY` if you want live AI replies.
4. Run `npm start` and open `http://localhost:3000`.

Without an API key, chat uses clearly labeled local story-mode sample replies. It is not a live AI conversation. Demo coins and shop items are not real-money purchases. Multiplayer, real phone calls, push services and payment processing are not implemented.

## Data
Characters, messages, theme settings and memories are saved in this browser's localStorage. Use Settings → Export Backup to save a JSON backup.
