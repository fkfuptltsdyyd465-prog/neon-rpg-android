const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');

function loadEnv() {
  const p = path.join(__dirname, '.env');
  if (!fs.existsSync(p)) return;
  for (const line of fs.readFileSync(p, 'utf8').split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)\s*$/);
    if (m && !process.env[m[1]]) process.env[m[1]] = m[2].replace(/^['"]|['"]$/g, '');
  }
}
loadEnv();
const PORT = Number(process.env.PORT || 3000);
const MODEL = process.env.OPENAI_MODEL || 'gpt-5.5';
const ROOT = __dirname;
const mime = {'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.jpg':'image/jpeg','.jpeg':'image/jpeg','.png':'image/png','.svg':'image/svg+xml','.json':'application/json'};
function send(res, status, data, type='application/json; charset=utf-8') { res.writeHead(status, {'Content-Type':type,'Cache-Control':'no-store'}); res.end(type.startsWith('application/json') ? JSON.stringify(data) : data); }
function readBody(req) { return new Promise((resolve,reject)=>{let s='';req.on('data',c=>{s+=c;if(s.length>1_000_000) reject(new Error('Request too large'));});req.on('end',()=>{try{resolve(JSON.parse(s||'{}'));}catch{reject(new Error('Invalid JSON'));}});req.on('error',reject);}); }
const server = http.createServer(async (req,res)=>{
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  if (req.method === 'GET' && url.pathname === '/api/health') return send(res,200,{ok:true,configured:Boolean(process.env.OPENAI_API_KEY),model:MODEL});
  if (req.method === 'POST' && url.pathname === '/api/chat') {
    if (!process.env.OPENAI_API_KEY) return send(res,503,{error:'API key is not configured. Add OPENAI_API_KEY to the .env file.'});
    try {
      const body = await readBody(req);
      const name = String(body.character || 'Rose').slice(0,50);
      const persona = String(body.persona || 'Gothic romantic, warm, witty and mysterious.').slice(0,500);
      const message = String(body.message || '').trim().slice(0,4000);
      const history = Array.isArray(body.history) ? body.history.slice(-16).map(x=>({role:x.role==='assistant'?'assistant':'user',content:String(x.content||'').slice(0,4000)})) : [];
      if (!message) return send(res,400,{error:'Message is required.'});
      const instructions = `You are ${name}, a fictional adult female character in the NEON RPG role-playing game. Personality: ${persona}. Stay in character, be emotionally expressive, imaginative and conversational. Continue the user's scene naturally. Never claim to be a real person. Reply in the same language as the user's latest message unless they request another language. Keep replies engaging and usually concise.`;
      const response = await fetch('https://api.openai.com/v1/responses', {
        method:'POST', headers:{'Authorization':`Bearer ${process.env.OPENAI_API_KEY}`,'Content-Type':'application/json'},
        body:JSON.stringify({model:MODEL,instructions,input:[...history,{role:'user',content:message}],max_output_tokens:500})
      });
      const data = await response.json();
      if (!response.ok) return send(res,response.status,{error:data.error?.message || 'OpenAI API request failed.'});
      const answer = data.output?.flatMap(item=>item.content||[]).filter(c=>c.type==='output_text').map(c=>c.text).join('\n').trim() || data.output_text || '';
      return send(res,200,{reply:answer || 'I am here… tell me more. ♡',responseId:data.id});
    } catch (err) { return send(res,500,{error:err.message || 'Server error'}); }
  }
  if (req.method !== 'GET' && req.method !== 'HEAD') return send(res,405,{error:'Method not allowed'});
  let file = decodeURIComponent(url.pathname === '/' ? '/index.html' : url.pathname);
  file = path.normalize(path.join(ROOT,file));
  if (!file.startsWith(ROOT)) return send(res,403,{error:'Forbidden'});
  fs.readFile(file,(err,buf)=>{if(err)return send(res,404,{error:'Not found'});res.writeHead(200,{'Content-Type':mime[path.extname(file)]||'application/octet-stream'});if(req.method==='HEAD')return res.end();res.end(buf);});
});
server.listen(PORT,()=>console.log(`NEON RPG running at http://localhost:${PORT} (model: ${MODEL})`));
