NEON RPG — OpenAI API edition

WHAT'S CONNECTED
- The Chat page sends messages to your own Node.js server.
- The server calls the OpenAI Responses API.
- Each heroine has a distinct character instruction and her own local chat history.
- The API key stays on the server in .env and is never sent to the browser.

REQUIREMENTS
- Node.js 18 or newer
- An OpenAI API key with API billing/credits enabled

SETUP
1. Extract this ZIP.
2. Copy .env.example and rename the copy to .env.
3. Open .env and replace your_api_key_here with your API key.
4. Keep the key private. Do not paste it into index.html or share the .env file.
5. Open a terminal in this folder and run: npm start
6. Open http://localhost:3000 in your browser.

MODEL
Default: gpt-5.5. Change OPENAI_MODEL in .env to another model available to your API account.

NOTES
- The API is used only for AI character chat. Other game systems remain local/demo features.
- Chat histories are stored in this browser's localStorage. They are not a cloud account or cross-device sync.
- API usage is billed by OpenAI according to the model and token rates on your API account.
- If you deploy this app publicly, add authentication, rate limiting, HTTPS, and per-user quotas before sharing it.

API documentation: https://developers.openai.com/api/docs/quickstart
